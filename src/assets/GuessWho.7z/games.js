// Key value comes from Strapi enumeration

const games = {
    "DGS12": "dgs1+2.webp",
    "trilogy": "Trilogy",
    "apollojustice": "apollojustice",
    "investigations": "investigations",
    "plvaa": "plvaa",
    "dualdestinies": "dualdestinies",
    "soj": "soj"
}
export default games